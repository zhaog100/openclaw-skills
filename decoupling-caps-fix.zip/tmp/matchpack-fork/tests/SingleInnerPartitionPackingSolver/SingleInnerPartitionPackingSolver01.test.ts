import { test, expect } from "bun:test"
import { SingleInnerPartitionPackingSolver } from "../../lib/solvers/PackInnerPartitionsSolver/SingleInnerPartitionPackingSolver"
import { PartitionInputProblem } from "../../lib/types/InputProblem"
import {
  InputProblem,
  ChipId,
  PinId,
} from "../../lib/types/InputProblem"

// Test input based on the provided JSON with enhanced decoupling capacitor layout
const testInputProblem: InputProblem = {
  chipMap: {
    "U3": {
      chipId: "U3",
      pins: ["U3.1", "U3.2"],
      size: { x: 3, y: 8.4 },
      availableRotations: [0, 90, 180, 270],
    },
    "C10": {
      chipId: "C10",
      pins: ["C10.1", "C10.2"],
      size: { x: 0.53, y: 1.06 },
      availableRotations: [0],
      isDecouplingCap: true,
    },
    "C11": {
      chipId: "C11",
      pins: ["C11.1", "C11.2"],
      size: { x: 0.53, y: 1.06 },
      availableRotations: [0],
      isDecouplingCap: true,
    },
  },
  chipPinMap: {
    "U3.1": {
      pinId: "U3.1",
      offset: { x: -1.9, y: 1.2 },
      side: "x-",
    },
    "U3.2": {
      pinId: "U3.2",
      offset: { x: -1.9, y: -1.8 },
      side: "x-",
    },
    "C10.1": {
      pinId: "C10.1",
      offset: { x: 0, y: 0.55 },
      side: "y+",
    },
    "C10.2": {
      pinId: "C10.2",
      offset: { x: 0, y: -0.55 },
      side: "y-",
    },
    "C11.1": {
      pinId: "C11.1",
      offset: { x: 0, y: 0.55 },
      side: "y+",
    },
    "C11.2": {
      pinId: "C11.2",
      offset: { x: 0, y: -0.55 },
      side: "y-",
    },
  },
  netMap: {
    "net_vcc": {
      netId: "net_vcc",
      isPositiveVoltageSource: true,
    },
    "net_gnd": {
      netId: "net_gnd",
      isGround: true,
    },
  },
  pinStrongConnMap: {
    "U3.1-C10.1": true,
    "C10.1-U3.1": true,
    "U3.2-C11.1": true,
    "C11.1-U3.2": true,
  },
  netConnMap: {
    "U3.1-net_vcc": true,
    "C10.1-net_vcc": true,
    "U3.2-net_vcc": true,
    "C11.1-net_vcc": true,
    "C10.2-net_gnd": true,
    "C11.2-net_gnd": true,
  },
  chipGap: 0.6,
  partitionGap: 1.2,
  decouplingCapsGap: 0.3,
  inferDecouplingCaps: true,
}

// Convert to PartitionInputProblem for decoupling caps
const partitionInputProblem: PartitionInputProblem = {
  ...testInputProblem,
  isPartition: true,
  partitionType: "decoupling_caps",
}

test("SingleInnerPartitionPackingSolver handles decoupling capacitors with horizontal layout", () => {
  // Create pin connectivity mapping
  const pinIdToStronglyConnectedPins: Record<PinId, Array<{ pinId: PinId; offset: { x: number; y: number } }>> = {
    "U3.1": [{ pinId: "C10.1", offset: { x: 0, y: 0.55 } }],
    "U3.2": [{ pinId: "C11.1", offset: { x: 0, y: 0.55 } }],
    "C10.1": [{ pinId: "U3.1", offset: { x: -1.9, y: 1.2 } }],
    "C10.2": [],
    "C11.1": [{ pinId: "U3.2", offset: { x: -1.9, y: -1.8 } }],
    "C11.2": [],
  }

  const solver = new SingleInnerPartitionPackingSolver({
    partitionInputProblem,
    pinIdToStronglyConnectedPins,
  })

  solver.solve()

  expect(solver.solved).toBe(true)
  expect(solver.layout).toBeTruthy()

  const layout = solver.layout!

  // Verify that all chips are placed
  expect(Object.keys(layout.chipPlacements)).toHaveLength(3)
  expect(layout.chipPlacements.U3).toBeDefined()
  expect(layout.chipPlacements.C10).toBeDefined()
  expect(layout.chipPlacements.C11).toBeDefined()

  // For decoupling capacitors, we expect them to be arranged horizontally
  // to minimize loop area and improve high-frequency performance
  const c10Pos = layout.chipPlacements.C10
  const c11Pos = layout.chipPlacements.C11

  // Decoupling caps should be placed close to their connected pins
  // C10 should be near U3.1, C11 should be near U3.2
  const u3Pos = layout.chipPlacements.U3

  // Verify that decoupling caps are positioned for optimal layout
  // They should be arranged to minimize trace length and loop area
  console.log("Chip placements:")
  console.log(`  U3: (${u3Pos.x}, ${u3Pos.y})`)
  console.log(`  C10: (${c10Pos.x}, ${c10Pos.y})`)
  console.log(`  C11: (${c11Pos.x}, ${c11Pos.y})`)

  // Verify that the layout respects the smaller gap for decoupling caps
  const distanceC10ToC11 = Math.sqrt(
    Math.pow(c10Pos.x - c11Pos.x, 2) + Math.pow(c10Pos.y - c11Pos.y, 2)
  )

  // Should use decouplingCapsGap (0.3) instead of regular chipGap (0.6)
  expect(distanceC10ToC11).toBeGreaterThanOrEqual(0.3)

  console.log(`Distance between C10 and C11: ${distanceC10ToC11.toFixed(3)}`)
  console.log(`Expected minimum gap: 0.3 (decoupling caps gap)`)
})

test("SingleInnerPartitionPackingSolver respects decoupling caps gap parameter", () => {
  const solver = new SingleInnerPartitionPackingSolver({
    partitionInputProblem,
    pinIdToStronglyConnectedPins: {},
  })

  solver.solve()

  expect(solver.solved).toBe(true)
  expect(solver.layout).toBeTruthy()

  // The solver should use the smaller decouplingCapsGap for packing
  // when partitionType is "decoupling_caps"
  const layout = solver.layout!

  // Verify that chips are placed with appropriate spacing
  const chipIds = Object.keys(layout.chipPlacements)
  expect(chipIds.length).toBeGreaterThan(1)

  // Check that the solver completed successfully with the specialized gap
  expect(solver.failed).toBe(false)
  expect(solver.error).toBeNull()
})