---
name: oil-gold-correlation
石油黄金实时相关性分析。获取大宗商品价格数据，计算多种相关性指标（Pearson/Spearman/Kendall），支持 DCC-GARCH 动态相关、Granger 因果检验、协整分析，输出可视化图表和自然语言结论。
version: 1.5.6
author: 小米粒 🌾
recommendModel: zai/glm-5
altModels:
  - zai/glm-5
  - qwen3-max
  - qwen3.5-plus
  - kimi-k2.5
---

# 石油黄金相关性分析

实时分析黄金（XAU/USD）和原油（WTI/Brent）之间的相关性，支持多种统计方法和可视化。

## 触发词

- "石油黄金相关性" / "原油黄金分析" / "gold oil correlation"
- "大宗商品关联" / "油价金价关系"
- "石油黄金" / "oil gold"
- "该买黄金吗" / "黄金投资建议" / "原油怎么投"
- "黄金买卖" / "石油基金" / "大宗商品投资"
- "国际形势" / "地缘分析" / "石油黄金新闻"

## 使用方式

当用户问及石油和黄金的关系、大宗商品关联性时，按以下流程执行：

### 1. 数据获取

```bash
python3 scripts/fetch_data.py [--period 1y] [--interval 1d]
```

使用 yfinance 获取数据（免费、无需 Key）：
- 黄金期货：`GC=F`
- WTI 原油：`CL=F`
- 布伦特原油：`BZ=F`

数据缓存 5 分钟，避免频繁请求。

### 2. 相关性分析

```bash
python3 scripts/analysis.py [--method all] [--window 30]
```

分析方法（从简单到高级）：

| 方法 | 说明 | 适用场景 |
|------|------|---------|
| Pearson | 线性相关性 | 基础分析 |
| Spearman | 秩相关性 | 非线性单调关系 |
| Kendall | 秩一致性 | 小样本稳健 |
| Rolling Correlation | 滚动窗口相关 | 相关性变化趋势 |
| Granger Causality | 因果方向 | 谁领先谁 |
| Cointegration (ADF) | 长期均衡 | 是否存在稳定关系 |
| DCC-GARCH | 动态条件相关 | 波动聚类下的相关性 |

### 3. 可视化

```bash
python3 scripts/visualize.py [--output media/oil-gold.html]
```

生成图表：
1. 价格走势叠加图（双 Y 轴）
2. 收益率散点图 + 回归线
3. 滚动相关系数时序图
4. 相关性热力图（多时间窗口）

### 4. 报告生成

```bash
python3 scripts/report.py [--period 1y]
```

输出自然语言分析结论，包含：
- 当前相关系数及解读
- 相关性趋势（增强/减弱）
- 因果关系方向（如有）
- 投资启示

## 时间窗口

| 命令 | 窗口 | 用途 |
|------|------|------|
| `7d` / `一周` | 7 天 | 短期波动 |
| `30d` / `一月` | 30 天 | 月度趋势 |
| `90d` / `一季度` | 90 天 | 中期走势 |
| `1y` / `一年` | 252 交易日 | 长期关系 |
| `滚动` | 30 日滚动窗口 | 相关性变化 |

### 5. 投资建议（短期 1天~1周）

```bash
python3 scripts/advisor.py [--days 3]
```

综合技术指标生成短期买卖建议，覆盖多品种：

| 品类 | 品种 | 代码 | 类型 |
|------|------|------|------|
| 黄金 | COMEX期货 | GC=F | 期货 |
| 黄金 | GLD ETF | GLD | 基金 |
| 黄金 | 现货 | XAUUSD=X | 现货 |
| 原油 | WTI期货 | CL=F | 期货 |
| 原油 | 布伦特期货 | BZ=F | 期货 |
| 原油 | USO ETF | USO | 基金 |
| 关联 | 美元指数 | DX-Y.NYB | 指数 |
| 关联 | 白银期货 | SI=F | 期货 |

技术指标：RSI(14) + MACD(12,26,9) + KDJ随机 + 布林带(20) + ATR(14) + OBV量价分析 + Fibonacci回撤 + 支撑/阻力位 + 黄金-原油比率 + 多时间框架分析
输出：评分、建议、操作策略、止盈止损价位、预测区间、量价背离、Fib区间

### v1.3.0 智能建议引擎
5大核心功能：
1. **动态权重系统** — 根据市场环境（趋势/震荡/高波动）自动调整指标权重
2. **信号冲突处理** — 多空分类 + 一致度计算 + 趋势指标优先
3. **置信度评分** — HIGH/MEDIUM/LOW 三级，基于一致度+信号强度+数量
4. **止损止盈建议** — ATR 1.5倍止损 + Fibonacci目标 + 风险回报比 ≥ 2:1
5. **仓位建议** — HIGH 2%/MEDIUM 1% 账户风险，LOW 不开仓

输出格式：方向 + 置信度 + 信号汇总(看多/看空) + 具体入场/止损/止盈价位 + 风险回报比 + 仓位 + 风险提示

## 定时推送

每天早上 **9:00 CST（北京时间）** 自动推送投资建议到 QQ。

已配置 cron job: `石油黄金每日投资参考`
- 时间: 每天 09:00 Asia/Shanghai
- 推送到: QQBot 私聊
- 内容: 短期分析(主) + 中长期趋势(辅) + 综合建议

手动触发: `openclaw cron run <job-id>`

## 注意事项

1. **数据单位**：黄金 USD/盎司，原油 USD/桶 — 量级不同，分析时用收益率（pct_change）
2. **交易时间**：周末/节假日无数据，自动跳过空值
3. **缓存**：数据缓存 5 分钟，避免 yfinance 限速
4. **相关性 ≠ 因果性**：报告时注意措辞，Granger 因果仅表示时序领先性
5. **regime switching**：不同市场状态（牛市/熊市/震荡）下相关性可能完全不同

## 依赖

- yfinance >= 0.2
- pandas >= 2.0
- numpy
- scipy >= 1.10
- plotly >= 5.0
- statsmodels（Granger/协整检验，可选）

---

Copyright (c) 2026 思捷娅科技 (SJYKJ) — MIT License
